import React, { useState, useEffect } from 'react';
import {
  Sun,
  MapPin,
  ShieldCheck,
  Zap,
  Sliders,
  HelpCircle,
  Activity,
  Layers,
  ArrowRight,
  RotateCcw,
  Sparkles,
  Info,
  Loader2,
  Building,
  CheckCircle,
} from 'lucide-react';
import { Header } from './components/Header';
import { LocationSearch } from './components/LocationSearch';
import { LeafletMap } from './components/LeafletMap';
import { SetupSelector } from './components/SetupSelector';
import { KnownSystemForm } from './components/KnownSystemForm';
import { RoofSetupFlow } from './components/RoofSetupFlow';
import { AssessmentResults } from './components/AssessmentResults';
import { WhyEstimateModal } from './components/WhyEstimateModal';
import { AdjustSystemModal } from './components/AdjustSystemModal';
import { LiveTelemetrySimulator } from './components/LiveTelemetrySimulator';
import { ObservabilityDrawer } from './components/ObservabilityDrawer';
import { HardwareGatewayModal } from './components/HardwareGatewayModal';
import { SolarAuditReportModal } from './components/SolarAuditReportModal';
import { PhoneSimulatorFrame } from './components/PhoneSimulatorFrame';

import {
  BuildingFootprint,
  GeoPoint,
  RoofConfiguration,
  SystemConfiguration,
  Assessment,
  SavedRoofProfile,
} from './types/solaris';
import { findNearbyBuildingFootprints, calculatePolygonAreaM2 } from './services/buildingFootprintService';
import { getSolarWeatherForecast } from './services/weatherService';
import { executePvlibForecast, orientationToAzimuth } from './services/pvlibEngine';
import {
  getSavedProfiles,
  saveRoofProfile,
  getAssessmentById,
} from './services/storageService';

export default function App() {
  // Navigation & Workflow state
  // 'location_pick' -> 'setup_choice' -> 'known_form' | 'roof_flow' -> 'results'
  const [currentStep, setCurrentStep] = useState<'location_pick' | 'setup_choice' | 'known_form' | 'roof_flow' | 'results'>('location_pick');

  // Map & Location State (Default: Makati CBD, Philippines)
  const [currentCenter, setCurrentCenter] = useState<GeoPoint>({ lat: 14.5547, lng: 121.0244 });
  const [currentAddress, setCurrentAddress] = useState<string>('Ayala Ave, Makati City, Metro Manila, Philippines');
  const [currentLocality, setCurrentLocality] = useState<string>('Makati CBD');
  const [nearbyBuildings, setNearbyBuildings] = useState<BuildingFootprint[]>([]);
  const [selectedBuilding, setSelectedBuilding] = useState<BuildingFootprint | null>(null);

  // Drawing mode for custom roof outline
  const [isDrawingMode, setIsDrawingMode] = useState(false);
  const [drawnPoints, setDrawnPoints] = useState<[number, number][]>([]);

  // Assessment & Forecasting State
  const [currentAssessment, setCurrentAssessment] = useState<Assessment | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [assessmentCount, setAssessmentCount] = useState(1);

  // Modals state
  const [showWhyModal, setShowWhyModal] = useState(false);
  const [showAdjustModal, setShowAdjustModal] = useState(false);
  const [showTelemetryModal, setShowTelemetryModal] = useState(false);
  const [showObservabilityModal, setShowObservabilityModal] = useState(false);
  const [showHardwareModal, setShowHardwareModal] = useState(false);
  const [showAuditReportModal, setShowAuditReportModal] = useState(false);

  // Saved Profiles State
  const [savedProfiles, setSavedProfiles] = useState<SavedRoofProfile[]>(getSavedProfiles());
  const [activeProfileId, setActiveProfileId] = useState<string | undefined>();

  // Responsive device viewport preview mode (default to phone format as requested)
  const [activeFormat, setActiveFormat] = useState<'phone' | 'tablet' | 'desktop'>('phone');
  const [phoneOrientation, setPhoneOrientation] = useState<'portrait' | 'landscape'>('portrait');

  // Fetch initial building footprints around default center
  useEffect(() => {
    loadBuildings(currentCenter.lat, currentCenter.lng);
  }, []);

  const loadBuildings = async (lat: number, lng: number) => {
    setIsLoading(true);
    try {
      const blds = await findNearbyBuildingFootprints(lat, lng, 300);
      setNearbyBuildings(blds);
      if (blds.length > 0) {
        setSelectedBuilding(blds[0]);
      }
    } catch (err) {
      console.error('Failed to find building footprints:', err);
    } finally {
      setIsLoading(false);
    }
  };

  // Handle location selection from search or preset
  const handleSelectLocation = (lat: number, lng: number, address: string, locality?: string) => {
    setCurrentCenter({ lat, lng });
    setCurrentAddress(address);
    setCurrentLocality(locality || address.split(',')[0]);
    loadBuildings(lat, lng);
    setCurrentStep('setup_choice');
  };

  // Handle map click
  const handleMapClick = (lat: number, lng: number) => {
    setCurrentCenter({ lat, lng });
    setCurrentAddress(`Selected Location (${lat.toFixed(4)}°N, ${lng.toFixed(4)}°E)`);
    loadBuildings(lat, lng);
    setCurrentStep('setup_choice');
  };

  // Handle building polygon selection on map
  const handleSelectBuilding = (bld: BuildingFootprint) => {
    setSelectedBuilding(bld);
    setCurrentCenter(bld.center);
    if (bld.address) setCurrentAddress(bld.address);
    setCurrentStep('setup_choice');
  };

  // Custom roof polygon drawing
  const handleAddDrawnPoint = (pt: [number, number]) => {
    const updated = [...drawnPoints, pt];
    setDrawnPoints(updated);

    if (updated.length >= 3) {
      const area = calculatePolygonAreaM2(updated);
      const customBld: BuildingFootprint = {
        id: `bld_custom_draw_${Date.now()}`,
        name: 'Custom Drawn Roof',
        address: currentAddress,
        center: currentCenter,
        geometry: {
          type: 'Polygon',
          coordinates: [[...updated, updated[0]]],
        },
        areaM2: area,
        confidence: 0.95,
        source: 'user_manual',
      };
      setSelectedBuilding(customBld);
    }
  };

  const handleClearDrawnPoints = () => {
    setDrawnPoints([]);
    setIsDrawingMode(false);
  };

  // Handle choice of setup path
  const handleSelectPath = (path: 'existing_system' | 'map_assisted' | 'auto') => {
    if (path === 'existing_system') {
      setCurrentStep('known_form');
    } else if (path === 'map_assisted') {
      setCurrentStep('roof_flow');
    } else if (path === 'auto') {
      handleExecuteAutoForecast();
    }
  };

  // Path 3: Execute Automatic Analysis
  const handleExecuteAutoForecast = async () => {
    const buildingArea = selectedBuilding?.areaM2 || 180;
    const usableAreaM2 = Math.round(buildingArea * 0.75);
    const capacityKwp = Math.round(((usableAreaM2 * 0.72 * 0.21 * 1000) / 1000) * 10) / 10 || 5.2;

    const roof: RoofConfiguration = {
      buildingAreaM2: buildingArea,
      usableAreaM2,
      usableRatio: 0.75,
      tiltDeg: 15,
      tiltCategory: 'slight',
      azimuthDeg: 180,
      orientationCategory: 'S',
      geometrySource: selectedBuilding?.source || 'open_buildings',
      confidence: 'medium',
    };

    const system: SystemConfiguration = {
      systemCapacityKwp: capacityKwp,
      panelCount: Math.ceil((capacityKwp * 1000) / 420),
      panelWattage: 420,
      inverterCapacityKw: Math.round(capacityKwp * 0.95 * 10) / 10,
      moduleEfficiency: 0.21,
      temperatureCoefficient: -0.0035,
      systemLossesPercent: 13.5,
      configurationSource: 'roof_derived',
    };

    await calculateForecast(roof, system, 'auto');
  };

  // Run full pvlib physical forecast pipeline
  const calculateForecast = async (
    roof: RoofConfiguration,
    system: SystemConfiguration,
    method: 'existing_system' | 'map_assisted' | 'manual' | 'auto'
  ) => {
    setIsLoading(true);
    try {
      const today = new Date();
      const weatherPayload = await getSolarWeatherForecast(currentCenter.lat, currentCenter.lng, today);
      const forecastResult = executePvlibForecast(
        currentCenter.lat,
        currentCenter.lng,
        today,
        roof,
        system,
        weatherPayload.hourly
      );

      const assessmentId = `assess_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
      const assessment: Assessment = {
        id: assessmentId,
        lat: currentCenter.lat,
        lng: currentCenter.lng,
        address: currentAddress,
        locality: currentLocality,
        building: selectedBuilding || undefined,
        roof,
        system,
        forecast: forecastResult,
        setupMethod: method,
        createdAt: new Date().toISOString(),
        claimed: false,
      };

      setCurrentAssessment(assessment);
      setAssessmentCount((prev) => prev + 1);
      setCurrentStep('results');
    } catch (err) {
      console.error('Error generating solar forecast:', err);
    } finally {
      setIsLoading(false);
    }
  };

  // Claim / Save assessment
  const handleSaveProfile = () => {
    if (!currentAssessment) return;
    const saved = saveRoofProfile(currentAssessment);
    setSavedProfiles(getSavedProfiles());
    setActiveProfileId(saved.id);
    setCurrentAssessment({ ...currentAssessment, claimed: true });
  };

  // Switch to saved profile
  const handleSelectSavedProfile = (profile: SavedRoofProfile) => {
    const cached = getAssessmentById(profile.assessmentId);
    if (cached) {
      setCurrentAssessment(cached);
      setCurrentCenter({ lat: cached.lat, lng: cached.lng });
      setCurrentAddress(cached.address);
      setCurrentLocality(cached.locality);
      setActiveProfileId(profile.id);
      setCurrentStep('results');
    } else {
      // Re-forecast with saved coordinates and capacity
      setCurrentCenter({ lat: profile.lat, lng: profile.lng });
      setCurrentAddress(profile.address);
      setActiveProfileId(profile.id);
      handleExecuteAutoForecast();
    }
  };

  // Recalculate on live system adjustment
  const handleApplyAdjustments = async (updatedRoof: RoofConfiguration, updatedSystem: SystemConfiguration) => {
    if (!currentAssessment) return;
    await calculateForecast(updatedRoof, updatedSystem, currentAssessment.setupMethod);
  };

  // Reset flow
  const handleReset = () => {
    setCurrentAssessment(null);
    setActiveProfileId(undefined);
    setCurrentStep('location_pick');
    setIsDrawingMode(false);
    setDrawnPoints([]);
  };

  return (
    <PhoneSimulatorFrame
      activeFormat={activeFormat}
      onChangeFormat={setActiveFormat}
      orientation={phoneOrientation}
      onToggleOrientation={() => setPhoneOrientation((o) => (o === 'portrait' ? 'landscape' : 'portrait'))}
    >
      <div className="min-h-full bg-slate-50 text-slate-800 font-['Plus_Jakarta_Sans'] antialiased flex flex-col selection:bg-indigo-100 selection:text-indigo-900">
        {/* Top Header Navigation */}
        <Header
          savedProfiles={savedProfiles}
          onSelectProfile={handleSelectSavedProfile}
          onOpenTelemetry={() => setShowTelemetryModal(true)}
          onOpenObservability={() => setShowObservabilityModal(true)}
          onReset={handleReset}
          activeProfileId={activeProfileId}
          hasAssessment={!!currentAssessment}
          activeFormat={activeFormat}
          onChangeFormat={setActiveFormat}
        />

        {/* Main Container */}
        <main className="flex-1 max-w-7xl w-full mx-auto px-3.5 py-5 sm:px-6 space-y-5 sm:space-y-6">
        {/* Step Banner / Breadcrumbs */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-xs font-semibold text-slate-400">
            <span
              onClick={() => setCurrentStep('location_pick')}
              className={`cursor-pointer transition-colors ${
                currentStep === 'location_pick' ? 'text-indigo-600 font-bold' : 'hover:text-slate-700'
              }`}
            >
              1. Location & Footprint
            </span>
            <span className="text-slate-300">›</span>
            <span
              onClick={() => currentAssessment && setCurrentStep('setup_choice')}
              className={`cursor-pointer transition-colors ${
                currentStep === 'setup_choice' || currentStep === 'known_form' || currentStep === 'roof_flow'
                  ? 'text-indigo-600 font-bold'
                  : 'hover:text-slate-700'
              }`}
            >
              2. System Setup
            </span>
            <span className="text-slate-300">›</span>
            <span
              className={`${currentStep === 'results' ? 'text-indigo-600 font-bold' : 'text-slate-400'}`}
            >
              3. Solar Generation Forecast
            </span>
          </div>

          <div className="hidden sm:flex items-center gap-2 text-xs text-slate-500 font-medium">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span>Open Building Datasets + pvlib Physical Modeling</span>
          </div>
        </div>

        {/* VIEW 1: LOCATION PICK & MAP INTERACTION */}
        {(currentStep === 'location_pick' || currentStep === 'setup_choice') && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            {/* Left Column: Search & Action Selector */}
            <div className="lg:col-span-5 space-y-4">
              <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-7 shadow-xs space-y-5">
                <div>
                  <h2 className="text-xl font-bold text-slate-900 font-['Space_Grotesk'] tracking-tight">
                    Find Your Solar Property
                  </h2>
                  <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                    Search your address or tap any building outline on the map. Solaris uses open satellite building footprints to estimate usable roof area.
                  </p>
                </div>

                {/* Location Search Input & Presets */}
                <LocationSearch
                  onSelectLocation={handleSelectLocation}
                  isLoading={isLoading}
                />
              </div>

              {/* Step 2 Subview: Setup Selector (when building is selected) */}
              {currentStep === 'setup_choice' && (
                <SetupSelector
                  selectedBuilding={selectedBuilding}
                  onSelectPath={handleSelectPath}
                  onChooseDifferentProperty={() => setCurrentStep('location_pick')}
                />
              )}
            </div>

            {/* Right Column: Interactive Map */}
            <div className="lg:col-span-7 space-y-2">
              <LeafletMap
                center={currentCenter}
                buildings={nearbyBuildings}
                selectedBuilding={selectedBuilding}
                onSelectBuilding={handleSelectBuilding}
                onMapClick={handleMapClick}
                isDrawingMode={isDrawingMode}
                drawnPoints={drawnPoints}
                onAddDrawnPoint={handleAddDrawnPoint}
                onClearDrawnPoints={handleClearDrawnPoints}
              />
              <div className="flex items-center justify-between text-[11px] text-slate-400 px-1 font-medium">
                <span>Layers: Esri World Imagery / OSM vector</span>
                <span>Spatial Index: Open Buildings & Microsoft ML</span>
              </div>
            </div>
          </div>
        )}

        {/* VIEW 2A: KNOWN SYSTEM SETUP FORM */}
        {currentStep === 'known_form' && (
          <div className="max-w-2xl mx-auto">
            <KnownSystemForm
              onBack={() => setCurrentStep('setup_choice')}
              onSubmit={(roof, sys) => calculateForecast(roof, sys, 'existing_system')}
              isLoading={isLoading}
            />
          </div>
        )}

        {/* VIEW 2B: MAP-ASSISTED ROOF SETUP FLOW */}
        {currentStep === 'roof_flow' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            <div className="lg:col-span-6">
              <RoofSetupFlow
                building={selectedBuilding}
                onBack={() => setCurrentStep('setup_choice')}
                onSubmit={(roof, sys) => calculateForecast(roof, sys, 'map_assisted')}
                onToggleDrawingMode={(enabled) => setIsDrawingMode(enabled)}
                isDrawingMode={isDrawingMode}
                isLoading={isLoading}
              />
            </div>
            <div className="lg:col-span-6">
              <LeafletMap
                center={currentCenter}
                buildings={nearbyBuildings}
                selectedBuilding={selectedBuilding}
                onSelectBuilding={handleSelectBuilding}
                onMapClick={handleMapClick}
                isDrawingMode={isDrawingMode}
                drawnPoints={drawnPoints}
                onAddDrawnPoint={handleAddDrawnPoint}
                onClearDrawnPoints={handleClearDrawnPoints}
              />
            </div>
          </div>
        )}

        {/* VIEW 3: ASSESSMENT RESULTS & GENERATION FORECAST */}
        {currentStep === 'results' && currentAssessment && (
          <div className="space-y-6">
            <AssessmentResults
              assessment={currentAssessment}
              onOpenWhyModal={() => setShowWhyModal(true)}
              onOpenAdjustModal={() => setShowAdjustModal(true)}
              onOpenHardwareModal={() => setShowHardwareModal(true)}
              onOpenAuditReportModal={() => setShowAuditReportModal(true)}
              onSaveProfile={handleSaveProfile}
              isSaved={currentAssessment.claimed || savedProfiles.some((p) => p.assessmentId === currentAssessment.id)}
            />
          </div>
        )}
      </main>

      {/* Loading Overlay */}
      {isLoading && (
        <div className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-slate-900/40 backdrop-blur-sm gap-3">
          <div className="w-14 h-14 rounded-3xl bg-white border border-slate-200 shadow-xl flex items-center justify-center text-indigo-600 animate-pulse">
            <Sun className="w-7 h-7 animate-spin-slow text-amber-500" />
          </div>
          <div className="text-center bg-white/95 px-6 py-3 rounded-2xl border border-slate-200 shadow-lg">
            <h4 className="text-sm font-bold text-slate-900">Calculating Solar Forecast</h4>
            <p className="text-xs text-slate-500 mt-0.5">Executing pvlib solar position, POA irradiance & thermal derating...</p>
          </div>
        </div>
      )}

      {/* Modals */}
      {showWhyModal && currentAssessment && (
        <WhyEstimateModal
          assessment={currentAssessment}
          onClose={() => setShowWhyModal(false)}
        />
      )}

      {showAdjustModal && currentAssessment && (
        <AdjustSystemModal
          assessment={currentAssessment}
          onClose={() => setShowAdjustModal(false)}
          onApplyChanges={handleApplyAdjustments}
        />
      )}

      {showTelemetryModal && (
        <LiveTelemetrySimulator
          assessment={currentAssessment}
          onClose={() => setShowTelemetryModal(false)}
        />
      )}

      {showHardwareModal && currentAssessment && (
        <HardwareGatewayModal
          assessment={currentAssessment}
          onClose={() => setShowHardwareModal(false)}
        />
      )}

      {showAuditReportModal && currentAssessment && (
        <SolarAuditReportModal
          assessment={currentAssessment}
          onClose={() => setShowAuditReportModal(false)}
        />
      )}

      {showObservabilityModal && (
        <ObservabilityDrawer
          onClose={() => setShowObservabilityModal(false)}
          assessmentCount={assessmentCount}
        />
      )}

      {/* Footer */}
      <footer className="border-t border-slate-200 bg-white py-6 px-4 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="font-bold text-slate-800 font-['Space_Grotesk']">SOLARIS</span>
            <span>— Open Solar Potential & Generation Forecasting</span>
          </div>
          <div className="flex items-center gap-4 text-slate-500">
            <span>Model: pvlib physical pipeline</span>
            <span>Weather: Open-Meteo Cache</span>
            <span>Footprints: Open Buildings & OSM</span>
          </div>
        </div>
      </footer>
    </div>
    </PhoneSimulatorFrame>
  );
}
