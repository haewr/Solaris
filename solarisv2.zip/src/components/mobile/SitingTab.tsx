import React, { useState, useEffect } from 'react';
import {
  Navigation,
  MapPin,
  Sun,
  ShieldCheck,
  HelpCircle,
  RotateCcw,
  Compass,
  Layers,
  ArrowRight,
  AlertTriangle,
  RefreshCw,
  CheckCircle2,
  Calendar,
  Thermometer,
  Zap,
} from 'lucide-react';
import {
  LocationCoordinates,
  RoofDimensions,
  NasaPowerClimatologyData,
  SolarMathCalculation,
} from '../../types/nativeSolaris';
import { nasaPowerService, DUMAGUETE_DEFAULT_COORDS } from '../../services/nasaPowerService';
import { WhyThisEstimateModal } from './WhyThisEstimateModal';
import { MapPinpointSheet } from './MapPinpointSheet';

interface SitingTabProps {
  location: LocationCoordinates;
  onChangeLocation: (loc: LocationCoordinates) => void;
  roof: RoofDimensions;
  onChangeRoof: (roof: RoofDimensions) => void;
  nasaData: NasaPowerClimatologyData | null;
  onNasaDataFetched: (data: NasaPowerClimatologyData, fromCache: boolean, cacheTs?: number) => void;
  isAirplaneMode: boolean;
  onNavigateToSimulation: () => void;
}

export const SitingTab: React.FC<SitingTabProps> = ({
  location,
  onChangeLocation,
  roof,
  onChangeRoof,
  nasaData,
  onNasaDataFetched,
  isAirplaneMode,
  onNavigateToSimulation,
}) => {
  const [isLoadingNasa, setIsLoadingNasa] = useState(false);
  const [nasaError, setNasaError] = useState<string | null>(null);
  const [isFromCache, setIsFromCache] = useState(false);
  const [cacheTimestamp, setCacheTimestamp] = useState<number | undefined>();
  const [showWhyModal, setShowWhyModal] = useState(false);
  const [showPinpointSheet, setShowPinpointSheet] = useState(false);
  const [gpsLoading, setGpsLoading] = useState(false);
  const [gpsError, setGpsError] = useState<string | null>(null);

  // Auto-fetch NASA POWER data on initial mount or when coordinates change
  useEffect(() => {
    fetchNasaData();
  }, [location.latitude, location.longitude, isAirplaneMode]);

  const fetchNasaData = async () => {
    setIsLoadingNasa(true);
    setNasaError(null);
    try {
      const res = await nasaPowerService.fetchClimatology(
        location.latitude,
        location.longitude,
        isAirplaneMode
      );
      setIsFromCache(res.fromCache);
      setCacheTimestamp(res.cacheTimestamp);
      onNasaDataFetched(res.data, res.fromCache, res.cacheTimestamp);
    } catch (err: any) {
      setNasaError(err.message || 'Failed to connect to NASA POWER satellite API.');
    } finally {
      setIsLoadingNasa(false);
    }
  };

  // Real GPS location acquisition with honest status
  const handleAcquireGps = () => {
    if (!navigator.geolocation) {
      setGpsError('Geolocation is not supported on this device.');
      return;
    }

    setGpsLoading(true);
    setGpsError(null);

    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setGpsLoading(false);
        const lat = pos.coords.latitude;
        const lng = pos.coords.longitude;
        const accuracy = Math.round(pos.coords.accuracy);
        onChangeLocation({
          latitude: lat,
          longitude: lng,
          accuracyMeters: accuracy,
          altitudeMeters: pos.coords.altitude || undefined,
          timestamp: Date.now(),
          source: 'gps',
          addressName: `GPS Device Fix (${lat.toFixed(4)}°N, ${lng.toFixed(4)}°E, ±${accuracy}m)`,
        });
      },
      (err) => {
        setGpsLoading(false);
        setGpsError(`GPS Access Refused or Unavailable: ${err.message}. Using manual pinpoint.`);
      },
      { enableHighAccuracy: true, timeout: 12000, maximumAge: 0 }
    );
  };

  // Roof Dimension validation & sanitization
  const handleDimensionChange = (field: keyof RoofDimensions, rawValue: string) => {
    const num = parseFloat(rawValue);
    const sanitized = isNaN(num) ? 0 : Math.max(0, num);

    const updated = { ...roof };

    if (field === 'widthMeters' || field === 'lengthMeters') {
      if (field === 'widthMeters') updated.widthMeters = Math.min(100, sanitized);
      if (field === 'lengthMeters') updated.lengthMeters = Math.min(100, sanitized);
      updated.totalAreaM2 = Math.round(updated.widthMeters * updated.lengthMeters * 10) / 10;
      updated.usableAreaM2 = Math.round(updated.totalAreaM2 * 0.75 * 10) / 10; // 75% usable
    } else if (field === 'usableAreaM2') {
      updated.usableAreaM2 = Math.min(2000, Math.max(5, sanitized));
      updated.totalAreaM2 = Math.round((updated.usableAreaM2 / 0.75) * 10) / 10;
    } else if (field === 'tiltDegrees') {
      updated.tiltDegrees = Math.min(90, Math.max(0, sanitized));
    } else if (field === 'azimuthDegrees') {
      updated.azimuthDegrees = Math.min(360, Math.max(0, sanitized));
      // Cardinal orientation name
      const az = updated.azimuthDegrees;
      if (az >= 337.5 || az < 22.5) updated.orientationName = 'North (0°)';
      else if (az >= 22.5 && az < 67.5) updated.orientationName = 'Northeast (45°)';
      else if (az >= 67.5 && az < 112.5) updated.orientationName = 'East (90°)';
      else if (az >= 112.5 && az < 157.5) updated.orientationName = 'Southeast (135°)';
      else if (az >= 157.5 && az < 202.5) updated.orientationName = 'South (180° Optimal)';
      else if (az >= 202.5 && az < 247.5) updated.orientationName = 'Southwest (225°)';
      else if (az >= 247.5 && az < 292.5) updated.orientationName = 'West (270°)';
      else updated.orientationName = 'Northwest (315°)';
    }

    onChangeRoof(updated);
  };

  // Compute standard physics model: E = A × r × H × PR
  const mathCalculation: SolarMathCalculation | null = nasaData
    ? nasaPowerService.calculateSolarMath(roof, nasaData)
    : null;

  return (
    <div className="space-y-4 pb-6" id="solaris-siting-tab">
      {/* Offline Cached Warning Banner */}
      {isFromCache && (
        <div className="p-3 rounded-2xl bg-amber-50 border border-amber-200 text-amber-900 text-xs flex items-center gap-2">
          <AlertTriangle className="w-4 h-4 shrink-0 text-amber-600" />
          <div className="leading-tight">
            <strong>Serving Cached NASA POWER Satellite Data</strong>
            <span className="block text-[10px] text-amber-700">
              Cached locally {cacheTimestamp ? new Date(cacheTimestamp).toLocaleDateString() : 'earlier'}. No new network calls made.
            </span>
          </div>
        </div>
      )}

      {/* 1. Location Siting Card */}
      <div className="bg-white rounded-3xl p-4 sm:p-5 border border-slate-200/90 shadow-xs space-y-3.5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center">
              <MapPin className="w-4 h-4" />
            </div>
            <span className="text-xs font-bold text-slate-900 uppercase tracking-wider">
              1. Site Location (Dumaguete City)
            </span>
          </div>
          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-indigo-50 text-indigo-700 border border-indigo-200">
            {location.source === 'gps' ? 'Real GPS' : 'Manual Pin'}
          </span>
        </div>

        {/* Current Location Display */}
        <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200/80 flex items-center justify-between gap-2">
          <div className="space-y-0.5 min-w-0 flex-1">
            <h4 className="text-xs font-bold text-slate-800 truncate">{location.addressName}</h4>
            <p className="text-[11px] font-mono text-slate-500">
              {location.latitude.toFixed(4)}°N, {location.longitude.toFixed(4)}°E
              {location.accuracyMeters ? ` (±${location.accuracyMeters}m)` : ''}
            </p>
          </div>
          <button
            onClick={() => setShowPinpointSheet(true)}
            className="px-3 py-2 rounded-xl bg-white border border-slate-200 text-slate-700 hover:bg-slate-100 text-xs font-bold shrink-0 transition-colors shadow-2xs"
          >
            Change Pin
          </button>
        </div>

        {/* GPS Trigger Button */}
        <button
          onClick={handleAcquireGps}
          disabled={gpsLoading}
          className="w-full py-2.5 px-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold flex items-center justify-center gap-2 transition-colors disabled:opacity-50"
        >
          <Navigation className={`w-3.5 h-3.5 text-indigo-600 ${gpsLoading ? 'animate-spin' : ''}`} />
          <span>{gpsLoading ? 'Acquiring Native GPS Fix...' : 'Acquire Current GPS Fix'}</span>
        </button>

        {gpsError && (
          <p className="text-[11px] text-rose-600 font-medium px-1">{gpsError}</p>
        )}
      </div>

      {/* 2. Roof Geometry Input Card */}
      <div className="bg-white rounded-3xl p-4 sm:p-5 border border-slate-200/90 shadow-xs space-y-3.5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center">
              <Layers className="w-4 h-4" />
            </div>
            <span className="text-xs font-bold text-slate-900 uppercase tracking-wider">
              2. Roof Dimensions & Orientation
            </span>
          </div>
          <span className="text-[11px] font-semibold text-slate-500">
            Usable: <strong>{roof.usableAreaM2} m²</strong>
          </span>
        </div>

        {/* Width & Length inputs */}
        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-1">
            <label className="text-[11px] font-bold text-slate-600 block">Roof Width (meters)</label>
            <div className="relative">
              <input
                type="number"
                min="1"
                max="100"
                step="0.5"
                value={roof.widthMeters}
                onChange={(e) => handleDimensionChange('widthMeters', e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:ring-2 focus:ring-indigo-500"
              />
              <span className="absolute right-3 top-2 text-[11px] text-slate-400 font-bold">m</span>
            </div>
          </div>

          <div className="space-y-1">
            <label className="text-[11px] font-bold text-slate-600 block">Roof Length (meters)</label>
            <div className="relative">
              <input
                type="number"
                min="1"
                max="100"
                step="0.5"
                value={roof.lengthMeters}
                onChange={(e) => handleDimensionChange('lengthMeters', e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:ring-2 focus:ring-indigo-500"
              />
              <span className="absolute right-3 top-2 text-[11px] text-slate-400 font-bold">m</span>
            </div>
          </div>
        </div>

        {/* Tilt & Azimuth sliders */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
          <div className="space-y-1.5 p-3 rounded-2xl bg-slate-50 border border-slate-200/80">
            <div className="flex items-center justify-between text-[11px]">
              <span className="font-bold text-slate-700">Roof Tilt Pitch:</span>
              <strong className="text-indigo-600 font-mono">{roof.tiltDegrees}°</strong>
            </div>
            <input
              type="range"
              min="0"
              max="60"
              value={roof.tiltDegrees}
              onChange={(e) => handleDimensionChange('tiltDegrees', e.target.value)}
              className="w-full accent-indigo-600 cursor-pointer h-1.5 bg-slate-200 rounded-lg"
            />
            <p className="text-[10px] text-slate-400">Dumaguete optimal latitude tilt is ~10°-15°</p>
          </div>

          <div className="space-y-1.5 p-3 rounded-2xl bg-slate-50 border border-slate-200/80">
            <div className="flex items-center justify-between text-[11px]">
              <span className="font-bold text-slate-700">Roof Azimuth Facing:</span>
              <strong className="text-indigo-600 font-mono">{roof.azimuthDegrees}° ({roof.orientationName.split(' ')[0]})</strong>
            </div>
            <input
              type="range"
              min="0"
              max="360"
              step="5"
              value={roof.azimuthDegrees}
              onChange={(e) => handleDimensionChange('azimuthDegrees', e.target.value)}
              className="w-full accent-indigo-600 cursor-pointer h-1.5 bg-slate-200 rounded-lg"
            />
            <p className="text-[10px] text-slate-400">180° South is optimal for Northern Hemisphere</p>
          </div>
        </div>
      </div>

      {/* 3. Real NASA POWER API Irradiance & Viability Results */}
      <div className="bg-white rounded-3xl p-4 sm:p-5 border border-slate-200/90 shadow-xs space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-xl bg-indigo-600 text-white flex items-center justify-center shadow-xs">
              <Sun className="w-4 h-4" />
            </div>
            <div>
              <span className="text-xs font-bold text-slate-900 uppercase tracking-wider block">
                3. Real Solar Viability (E = A × r × H × PR)
              </span>
              <span className="text-[10px] text-slate-500 font-medium">NASA POWER Climatology (MERRA-2)</span>
            </div>
          </div>

          <button
            onClick={fetchNasaData}
            disabled={isLoadingNasa}
            className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-600 transition-colors"
            title="Refresh NASA POWER satellite query"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isLoadingNasa ? 'animate-spin text-indigo-600' : ''}`} />
          </button>
        </div>

        {/* Loading State */}
        {isLoadingNasa && (
          <div className="py-8 flex flex-col items-center justify-center space-y-2">
            <div className="w-8 h-8 border-3 border-indigo-600 border-t-transparent rounded-full animate-spin" />
            <p className="text-xs text-slate-500 font-medium">
              Querying real multi-year satellite solar irradiance from NASA POWER API...
            </p>
          </div>
        )}

        {/* Real API Error State (No fake fallback) */}
        {!isLoadingNasa && nasaError && (
          <div className="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 space-y-2">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-rose-600" />
              <strong className="text-xs">NASA POWER API Connection Error</strong>
            </div>
            <p className="text-[11px] text-rose-700 leading-relaxed">{nasaError}</p>
            <button
              onClick={fetchNasaData}
              className="mt-1 px-3 py-1.5 rounded-xl bg-rose-600 text-white text-xs font-bold hover:bg-rose-700 transition-all"
            >
              Retry Satellite Query
            </button>
          </div>
        )}

        {/* Valid Real Results */}
        {!isLoadingNasa && mathCalculation && nasaData && (
          <div className="space-y-4">
            {/* Primary Energy KPI grid */}
            <div className="grid grid-cols-2 gap-3">
              <div className="p-3.5 rounded-2xl bg-indigo-50/70 border border-indigo-200/80 space-y-1">
                <span className="text-[10px] font-bold text-indigo-800 uppercase tracking-wider block">
                  Expected Daily Output
                </span>
                <div className="flex items-baseline gap-1">
                  <span className="text-2xl font-black font-['Space_Grotesk'] text-indigo-700">
                    {mathCalculation.dailyEnergyKwh}
                  </span>
                  <span className="text-xs font-bold text-indigo-600">kWh/day</span>
                </div>
                <p className="text-[10px] text-indigo-900/70 font-medium">
                  ~{mathCalculation.monthlyEnergyKwh} kWh / month
                </p>
              </div>

              <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 space-y-1">
                <span className="text-[10px] font-bold text-slate-600 uppercase tracking-wider block">
                  Estimated Annual Generation
                </span>
                <div className="flex items-baseline gap-1">
                  <span className="text-2xl font-black font-['Space_Grotesk'] text-slate-900">
                    {mathCalculation.annualEnergyKwh.toLocaleString()}
                  </span>
                  <span className="text-xs font-bold text-slate-600">kWh/yr</span>
                </div>
                <p className="text-[10px] text-slate-500 font-medium">
                  Recommended: ~{mathCalculation.recommendedSystemSizeKwp} kWp DC
                </p>
              </div>
            </div>

            {/* Real NASA Satellite Irradiance Badge */}
            <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200/80 flex items-center justify-between text-xs">
              <div className="space-y-0.5">
                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500 block">
                  NASA Climatological Irradiance (H)
                </span>
                <div className="flex items-center gap-1.5">
                  <strong className="text-slate-800 font-bold font-mono">
                    {nasaData.annualDailyKwhM2} kWh/m²/day
                  </strong>
                  <span className="text-slate-400">•</span>
                  <span className="text-slate-600 text-[11px]">Avg Ambient: {nasaData.annualAvgTempC}°C</span>
                </div>
              </div>
              <span className="px-2 py-1 rounded-lg bg-emerald-50 text-emerald-800 border border-emerald-200 text-[10px] font-bold">
                REAL SATELLITE
              </span>
            </div>

            {/* Explainability & Literature Confidence Button */}
            <div className="flex items-center justify-between gap-2 pt-1">
              <button
                onClick={() => setShowWhyModal(true)}
                className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-indigo-700 text-xs font-bold border border-slate-200 transition-colors"
              >
                <HelpCircle className="w-3.5 h-3.5" />
                <span>Why this estimate? (Formula & ±10.4% Citation)</span>
              </button>

              <button
                onClick={onNavigateToSimulation}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shadow-md shadow-indigo-100 active:scale-98 transition-all shrink-0"
              >
                <span>Run Simulation</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Why This Estimate Modal */}
      {showWhyModal && mathCalculation && nasaData && (
        <WhyThisEstimateModal
          math={mathCalculation}
          nasaData={nasaData}
          roof={roof}
          onClose={() => setShowWhyModal(false)}
        />
      )}

      {/* Map Pinpoint Sheet */}
      {showPinpointSheet && (
        <MapPinpointSheet
          currentLocation={location}
          onConfirmLocation={onChangeLocation}
          onClose={() => setShowPinpointSheet(false)}
        />
      )}
    </div>
  );
};
